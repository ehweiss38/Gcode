from helpers import modFloor,calcEndpoint,LineBoundaries,setCircleVals,setValues,calcChordSpace
from os import path

thickness=setCircleVals('thickness',50)
radius=setCircleVals('radius',170)
buffer=setCircleVals('buffer',10)
increment=setCircleVals('increment',10)

#important to remember you need actual values not just decimals

#the main improvement that is needed is that when it is above the circle, it no longer needs to follow the outline and can do the whole square



fileName=input('Enter file name')
if len(fileName)==0:fileName="testGcode"
fileName+='.txt'
f=None 


if path.isfile(fileName):f=open(fileName,"w")
else: f=open(fileName,"x")


f.write("G21\n")
#absolute mode
f.write("G90;\n")
4
#feed speed, possibly redundant
f.write("F25;\nF500;\n")

#assumes center start position 
f.write("G28.3 X0 Y0 Z0 ;\n")

x=0

yTarg=modFloor(radius-buffer,increment)
y=yTarg
#not sure if this is ideal
f.write(f"G X{x} Y{yTarg} Z0 ;(chilipeppr_pause);\n\n")

#can still do it otherwise, just only go as far as if it divisible
#deciding to work from center, even though it takes longer
#reason being is other wise, there could be some combinations of buffers and increments that wouldnt be centered a 0
yStart=yTarg
yFinish=-yTarg
downwards=True
rightwards=True
zMin=-1*setCircleVals('z-min',60)
z=zMin
zIncrement=setCircleVals('z-increment',30)
zTarg=setCircleVals('z-max',60)

while(z<=0):
    f.write(f"G1 X{x} Y{y} Z{z} ;\n\n")
    #need to consider endpoint, returning to that center spot
    while(y>=yFinish if downwards else y<=yFinish):
        y+=-increment if downwards else increment
        line=LineBoundaries(y)
        line.end=calcEndpoint(radius,y,increment,buffer)
        x=-line.end if rightwards else line.end
        xTarg=-x
        f.write(f"G1 X{x} Y{y};\n")
        while x<xTarg if rightwards else x>xTarg:
            x+=increment if rightwards else -increment
            #if y==yFinish:x=0
            f.write(f"G1 X{x} Y{y};\n")
        rightwards=False if rightwards else True
    downwards=False if downwards else True
    z+=zIncrement
    yFinish=-yFinish
    
f.write(f"G0 X0 Y0 Z{z}")

z-=zIncrement
#clearance so it doesnt hit side
f.write(f"G0 X0 Y0 Z{z}")

#cable will stick out of fron
#f.write()

#outer process, starts in middle, does left, goes back to middle along sides, does right
##also need to consider error processing, that x y have to be greater than outer plus buffer

oRadius=radius+thickness
xMax=None
#need to further consider negative cases
while xMax==None:
    xMax=setValues('x',True,250,oRadius)
    if xMax==None:print(f"Value must be greater than outer-radius({oRadius})")
xMin=None
while xMin==None:
    xMin=-abs(setValues('x',True,250,oRadius))
    if xMax==None:print(f"Value must be greater than outer-radius({oRadius})")
yMax=None
while yMax==None:
    yMax=setValues('y',True,250,oRadius)
    if yMax==None:print(f"Value must be greater than outer-radius({oRadius})")
yMin=None
while yMin==None:
    yMin=-abs(setValues('y',True,250,oRadius))
    if yMax==None:print(f"Value must be greater than outer-radius({oRadius})")
y=yMax


print(xMin,xMax)

tailCoord=0


while(z>=zMin):
    #print('Z',z)
    f.write(f"G1 X{x} Y{yMax} Z{z};\n")
    for i in range(0,2):
        tailSpace=False
        rightwards=True if i==1 else False
        xTarg=xMax if rightwards else xMin
        #tecnically overshoots a little and goes back
        while y>=yMin:
            #still need to put line switch in 
            #also need to consider before where circle starts
                #logic would be if(abs(y)>oRadius)
            while x<xTarg if rightwards else x>xTarg:
                x+=increment if rightwards else -increment
                f.write(f"G1 X{x} Y{y};\n")
            y-=increment
            rightwards=False if rightwards else True
            line=LineBoundaries(y)
            #print(y,oRadius)
            #best way is to adjust for widest point in circle before it closes
            #more specifically wide enough to fit thickness and buffer
            #when it reaches that width on bottom 
            line.end=(calcEndpoint(oRadius,y,increment,buffer,False) * (-1 if i==0 else 1)) if abs(y)<oRadius else (0 if tailSpace==False else (-tailCoord if i==0 else tailCoord))
            #print(line.end*2,thickness)
            if tailCoord==0 and line.end!=xMax and line.end!=xMin and abs(line.end*2)>thickness+buffer:
                tailCoord=abs(line.end)
                print("tailcoord",tailCoord)
            
            if abs(line.end)<=tailCoord and y<0:
                tailSpace=True

            xTarg=(line.end if rightwards else xMin) if i==0 else ((xMax if rightwards else line.end))
            #print(x,line.end,rightwards)
            x=(x if rightwards else line.end) if i==0 else ((line.end if rightwards else x))
            f.write(f"G1 X{x} Y{y};\n")
            #add cable gap later 
        if x!=(xMin if i==0 else xMax):
            #doesnt need to redeclare but i feel like it majkes it more clear/ easier to trace flow & errorss
            x=xMin if i==0 else xMax
        #f.write(f"G0 X{x} Y{y};\n")
        #i am a little confused about the little tails but it is not a huge deal
        y=yMax
        f.write(f"G0 X{x} Y{yMax};\n")
        x=0
        f.write(f"G0 X{x} Y{yMax};\n")
    z-=zIncrement

f.write(f"G0 X{x} Y{y} Z{zTarg};\n")

#few issues, need seperate variables for coil height and total height, so know when to switch to others, because 0 is in center of coil


#cant do these moves, need to really consider possibilities
#f.write(f"G0 X0 Y0 Z0;")
#f.write(f"G0 X{xMin} Y{xMin} Z0")

#square here

while(z<=zTarg):
#a little connfusing but low meaninng start, high finish, irrespective of actual values
    lowY=yMax if downwards else yMin
    highY=yMin if downwards else yMax
    y=lowY
    while((downwards and y>=highY) or (downwards==False and y<=highY)):
        lowX=xMin if rightwards else xMax
        highX=xMax if rightwards else xMin
        x=lowX
        while (x!=highX):
            x+=increment if rightwards else -1*increment
            f.write(f"G1 X{x};\n")
    
        #end behavior
        rightwards=False if rightwards else True
        if y!=highY:y+=-1*increment if downwards else increment
        else: break
        f.write(f"G1 X{x} Y{y} Z{z} ;\n")
        print(f"{y}-y {z}-z level complete\n")
    if z!=zTarg:z+=zIncrement
    else:break
    
    f.write(f"G1 X{x} Y{y} Z{z} (chilipeppr_pause);G4 P1 (new);\n")
    downwards=False if downwards else True
    print(f"{z} z level complete\n")

f.write(f"G0 X0 Y0;")
f.write(f"G X0 Y0 Z0;")
print('closing')
f.close()

f.close()
print('complete')
    